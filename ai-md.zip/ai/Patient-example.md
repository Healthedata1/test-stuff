# Patient Example - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Example**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Narrative Content](#) 
*  [JSON](Patient-example.json.md) 

## Example Patient: Patient Example

Profile: `http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient`

Amy V. Baxter (no stated gender), DoB: 1987-02-20 ( Medical Record Number: 1032702 (use: usual, ))

-------

| | |
| :--- | :--- |
| Active: | true |
| Alt. Name: | Amy V. Shaw (Old) |
| Contact Detail | * ph: 555-555-5555(Home)
* [amy.shaw@example.com](mailto:amy.shaw@example.com)
* 49 MEADOW ST MOUNDS OK 74047 US (old)
* 183 MOUNTAIN VIEW ST MOUNDS OK 74048 US 
 |
| Language: | Spanish(preferred) |
| US Core Ethnicity Extension: | * ombCategory: [CDC Race and Ethnicity 2135-2](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2135-2): Hispanic or Latino
* detailed: [CDC Race and Ethnicity 2184-0](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2184-0): Dominican
* detailed: [CDC Race and Ethnicity 2148-5](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2148-5): Mexican
* text: Hispanic or Latino
 |
| US Core Race Extension: | * ombCategory: [CDC Race and Ethnicity 2106-3](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2106-3): White
* ombCategory: [CDC Race and Ethnicity 1002-5](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-1002-5): American Indian or Alaska Native
* ombCategory: [CDC Race and Ethnicity 2028-9](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2028-9): Asian
* detailed: [CDC Race and Ethnicity 1586-7](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-1586-7): Shoshone
* detailed: [CDC Race and Ethnicity 2036-2](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html#CDCREC-2036-2): Filipino
* text: Mixed
 |

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

