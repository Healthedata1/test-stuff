# Test Binding - JSON Representation - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Binding**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](StructureDefinition-test-binding.md) 
*  [Detailed Descriptions](StructureDefinition-test-binding-definitions.md) 
*  [Examples](StructureDefinition-test-binding-examples.md) 
*  [JSON](#) 

## Resource Profile: TestBinding - JSON Profile

| |
| :--- |
| Draft as of 2025-08-22 |

JSON representation of the test-binding resource profile.

[Raw json](StructureDefinition-test-binding.json) | [Download](StructureDefinition-test-binding.json)

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

