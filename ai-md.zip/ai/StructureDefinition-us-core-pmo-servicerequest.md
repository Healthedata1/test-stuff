# US Core PMO ServiceRequest Profile - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core PMO ServiceRequest Profile**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-us-core-pmo-servicerequest-definitions.md) 
*  [Examples](StructureDefinition-us-core-pmo-servicerequest-examples.md) 
*  [JSON](StructureDefinition-us-core-pmo-servicerequest.profile.json.md) 

## Resource Profile: US Core PMO ServiceRequest Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/core/StructureDefinition/us-core-pmo-servicerequest | *Version*:0.1.0 |
| Draft as of 2025-08-26 | *Computable Name*:USCorePMOServiceRequestProfile |

 
The US Core PMO ServiceRequest Profile inherits from the[FHIR ServiceRequest](https://hl7.org/fhir/R4/servicerequest.html)resource; refer to it for scope and usage definitions. This profile represents an order based on a PMO document and references the[US Core ADI DocumentReference Profile](StructureDefinition-us-core-adi-documentreference.md)to communicate the contents of the PMO document, such as POLST, MOLST, or other state-specific forms. PMO documents follow the patient across care settings and are typically stored as scanned images in EMRs/EHRs. Together, these two profiles satisfy the USCDI's PMO Order Data Element's intent to represent orders based on an individual's PMO. The US Core PMO ServiceRequest Profile establishes minimum expectations for recording, searching, and fetching PMO-related ServiceRequest information, specifying core elements, extensions, vocabularies, and value sets that SHALL be present to promote interoperability. 

The decision to add the US Core PMO Service Request Profile and to meet the USCDI's PMO Order Data Element definition sparked a healthy debate on whether `ServiceRequest` is necessary for actionable orders or if `DocumentReference` is sufficient for PMO portability and patient access.

The rationale for adding ServiceRequest to represent the USCDI PMO Order includes:

1. **Enhancing Patient Access and Care**: ServiceRequest enables actionable orders; without it, patient access and care goals are not fully met.
1. **Tracking PMO Implementation**A derivative order via ServiceRequest is necessary to demonstrate that the PMO has followed the patient.

The concerns include:

1. **Incomplete Representation**: A`ServiceRequest`reflects only part of a PMO order and may not fully capture the PMO's scope.
1. **Scope Creep Beyond USCDI**: Concerns that it goes beyond USCDI requirements by including derivative orders.
1. **Unnecessary Complexity**:`ServiceRequest`could add unnecessary complexity without clear justification.
1. **Sufficiency of Current Design**: The current`DocumentReference`-based design already meets PMO requirements for USCDI

We request feedback on the clinical utility of this profile and its implications for certification

.

**Example Usage Scenarios:**

The following are example usage scenarios for this profile:

* Query for a specific procedure
* Query for a category of service request

### Mandatory and Must Support Data Elements

The following data elements must always be present ([Mandatory] definition) or must be supported if the data is present in the sending system ([Must Support](must-support.md) definition). They are presented below in a simple human-readable explanation. Profile specific guidance and examples are provided as well. The [Formal Views] below provides the formal summary, definitions, and terminology requirements.

**Each Service Request Must Have:**

1. a status
1. an intent code indicating whether the request is a proposal, plan, or order.
1. a code or plain text representation defining what is being requested*
1. a patient

**Each Service Request Must Support:**

1. a category
1. plain text representation of what is being requested*
1. a code or plain text representation of additional order details*
1. the encounter in which the request was created
1. when the requested service should happen
1. when the request was made
1. the requester*
1. the code for the test, procedure, or service to be performed
1. a reason or indication for referral or consultation

*see guidance below

### Profile Specific Implementation Guidance

This section provides detailed implementation guidance for the US Core Profile to support implementation and certification.

* This profile is intended for use when documenting derived medical orders after reviewing a patient's Portable Medical Order (PMO) — such as POLST, MOLST, or other state-specific forms. It is scoped to facility-based care environments where actionable orders are implemented, including hospitals, skilled nursing facilities, long-term care, and outpatient procedure centers (e.g., surgery centers, dialysis facilities). 
* This profile is not intended for routine ambulatory or office-based practice settings, where PMOs may be reviewed, but new standing orders are not typically derived.
 
* Although the `ServiceRequest.code` is bound to US Core Procedure Codes, a broadly defined value set that accommodates many healthcare domains, it has several additional bindings based on the PMO categories found in `ServiceRequest.category`. The additional bindings are displayed in `ServiceRequest.code`'s Description and Constrain column in the formal definition below.
* Often, plain text is used instead of codes to define what is being requested/ordered and for additional order details.

**Usages:**

* Examples for this Profile: [ServiceRequest/servicerequest-pmo-example1](ServiceRequest-servicerequest-pmo-example1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.us.healthedata1-sandbox|current/StructureDefinition/us-core-pmo-servicerequest)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ServiceRequest](http://hl7.org/fhir/R4/servicerequest.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [ServiceRequest](http://hl7.org/fhir/R4/servicerequest.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 15 elements

**Structures**

This structure refers to these other structures:

* [US Core Patient Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-patient.html)
* [US Core Encounter Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-encounter.html)
* [US Core Practitioner Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitioner.html)
* [US Core Organization Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-organization.html)
* [US Core ADI DocumentReference Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-adi-documentreference)](StructureDefinition-us-core-adi-documentreference.md)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-condition (no profile found)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-observation (no profile found)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-diagnosticreport (no profile found)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of ServiceRequest.category

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ServiceRequest](http://hl7.org/fhir/R4/servicerequest.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ServiceRequest](http://hl7.org/fhir/R4/servicerequest.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 15 elements

**Structures**

This structure refers to these other structures:

* [US Core Patient Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-patient.html)
* [US Core Encounter Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-encounter.html)
* [US Core Practitioner Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitioner.html)
* [US Core Organization Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-organization.html)
* [US Core ADI DocumentReference Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-adi-documentreference)](StructureDefinition-us-core-adi-documentreference.md)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-condition (no profile found)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-observation (no profile found)
* Unable to summarise profile http://hl7.org/fhir/StructureDefinition/us-core-diagnosticreport (no profile found)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of ServiceRequest.category

 

Other representations of profile: [CSV](StructureDefinition-us-core-pmo-servicerequest.csv), [Excel](StructureDefinition-us-core-pmo-servicerequest.xlsx), [Schematron](StructureDefinition-us-core-pmo-servicerequest.sch) 

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

