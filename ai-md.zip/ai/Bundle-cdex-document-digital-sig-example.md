# CDEX Document with Digital Signature Example - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDEX Document with Digital Signature Example**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Narrative Content](#) 
*  [JSON](Bundle-cdex-document-digital-sig-example.json.md) 

## Example Bundle: CDEX Document with Digital Signature Example

**Document Details**

Profile: `http://hl7.org/fhir/us/davinci-cdex/StructureDefinition/cdex-signature-bundle`

Final Document at 2021-10-25 20:16:29-0700 by [Example Practitioner](Bundle-cdex-document-digital-sig-example.md#urn-uuid-0820c16d-91de-4dfa-a3a6-f140a516a9bc) for [Example Patient](Bundle-cdex-document-digital-sig-example.md#urn-uuid-970af6c9-5bbd-4067-b6c1-d9b2c823aece) in encounter [Example Encounter](Bundle-cdex-document-digital-sig-example.md#urn-uuid-5ce5c83a-000f-47d2-941c-039358cc9112)

-------

**Document Subject**

### Patient Information

CDEX Example Patient, a male, is identified by member ID Member123 in the payer system http://example.org/cdex/payer/member-ids. He is the subject of this medical records document. The patient said, "I feel great!"

-------

**Document Content**

### Medical Records Document

This document, titled "Active Conditions," was created on October 25, 2021, by Dr. John Hancock, who also legally attested to its accuracy on the same date. It summarizes the active medical conditions for a patient based on an emergency encounter on October 25, 2021. The document includes one section detailing an active condition: Type 2 Diabetes Mellitus.

-------

## Active Condition 1

-------

## Additional Resources Included in Document

-------

Entry 2 - fullUrl = urn:uuid:0820c16d-91de-4dfa-a3a6-f140a516a9bc

Resource Practitioner:

> 

### Practitioner Information

Dr. John Hancock is a healthcare provider with National Provider Identifier (NPI) 9941339100. He authored and attested to the medical records document.

-------

Entry 3 - fullUrl = urn:uuid:970af6c9-5bbd-4067-b6c1-d9b2c823aece

Resource Patient:

> 

### Patient Information

CDEX Example Patient, a male, is identified by member ID Member123 in the payer system http://example.org/cdex/payer/member-ids. He is the subject of this medical records document. The patient said, "I feel great!"

-------

Entry 4 - fullUrl = urn:uuid:014a68ec-d691-49e0-b980-91b0d924e570

Resource Condition:

> 

### Active Condition

The patient has an active diagnosis of Type 2 Diabetes Mellitus (SNOMED CT: 44054006), first identified in 2006. This condition was documented by Dr. John Hancock and is listed as a problem on the patient’s problem list.

-------

Entry 5 - fullUrl = urn:uuid:5ce5c83a-000f-47d2-941c-039358cc9112

Resource Encounter:

> 

### Encounter Details

An emergency encounter occurred on October 25, 2021, from 8:10 PM to 8:16 PM, involving CDEX Example Patient and attended by Dr. John Hancock at CDEX Example Organization. The encounter type is unspecified (SNOMED CT: 261665006).

-------

Entry 6 - fullUrl = urn:uuid:e37f004b-dc10-422b-b833-cdaa10a055a3

Resource Organization:

> 

### Organization Information

CDEX Example Organization, located at 1 CDEX Lane, Boston, MA 01002, USA, is the service provider for the documented encounter. Contact details include phone: (+1) 555-555-5555 and email: customer-service@example.org. The organization's NPI is 1234567893.

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

