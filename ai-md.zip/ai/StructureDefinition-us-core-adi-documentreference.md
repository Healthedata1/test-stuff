# US Core ADI DocumentReference Profile - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core ADI DocumentReference Profile**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-us-core-adi-documentreference-definitions.md) 
*  [Examples](StructureDefinition-us-core-adi-documentreference-examples.md) 
*  [JSON](StructureDefinition-us-core-adi-documentreference.profile.json.md) 

## Resource Profile: US Core ADI DocumentReference Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/core/StructureDefinition/us-core-adi-documentreference | *Version*:0.1.0 |
| Active as of 2023-10-17 | *Computable Name*:USCoreADIDocumentReferenceProfile |

 
The US Core ADI DocumentReference Profile inherits from the FHIR[DocumentReference](https://hl7.org/fhir/R4/documentreference.html)resource; refer to it for scope and usage definitions. This profile and the[US Core Observation ADI Documentation Profile](StructureDefinition-us-core-observation-adi-documentation.md)meet the[U.S. Core Data for Interoperability (USCDI)](https://www.healthit.gov/isp/united-states-core-data-interoperability-uscdi)**Advance Directive Observation**Data Element requirements. It sets minimum expectations for searching and fetching patient Advance Directive Information (ADI) documents using the DocumentReference resource. Examples of advance healthcare directive documents include physician order for life sustaining treatment (POLST), do not resuscitate order (DNR), and medical power of attorney. In addition to the document contents, it communicates the type of advance directive document, the author, the verifier, and other properties. To represent whether advance directive documents exist for a patient, see the US Core Observation ADI Documentation Profile. This profile sets minimum expectations for searching and fetching patient ADI documents using the DocumentReference resource. It specifies which core elements, extensions, vocabularies, and value sets**SHALL**be present and constrains how the elements are used. Providing the floor for standards development for specific use cases promotes interoperability and adoption. 

**Usages:**

* Refer to this Profile: [US Core PMO ServiceRequest Profile](StructureDefinition-us-core-pmo-servicerequest.md) and [US Core Observation ADI Documentation Profile](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-observation-adi-documentation.html)
* Examples for this Profile: [DocumentReference/polst](DocumentReference-polst.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.us.healthedata1-sandbox|current/StructureDefinition/us-core-adi-documentreference)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 15 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [US Core Patient Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-patient.html)
* [US Core Practitioner Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitioner.html)
* [US Core Organization Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-organization.html)
* [US Core PractitionerRole Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitionerrole)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitionerrole.html)
* [US Core RelatedPerson Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-relatedperson)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-relatedperson.html)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-DocumentReference.attester](http://hl7.org/fhir/R4/documentreference-definitions.html#DocumentReference.attester)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of DocumentReference.category

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 15 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [US Core Patient Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-patient.html)
* [US Core Practitioner Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitioner.html)
* [US Core Organization Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-organization.html)
* [US Core PractitionerRole Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitionerrole)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-practitionerrole.html)
* [US Core RelatedPerson Profile(http://hl7.org/fhir/us/core/StructureDefinition/us-core-relatedperson)](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-relatedperson.html)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-DocumentReference.attester](http://hl7.org/fhir/R4/documentreference-definitions.html#DocumentReference.attester)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of DocumentReference.category

 

Other representations of profile: [CSV](StructureDefinition-us-core-adi-documentreference.csv), [Excel](StructureDefinition-us-core-adi-documentreference.xlsx), [Schematron](StructureDefinition-us-core-adi-documentreference.sch) 

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

