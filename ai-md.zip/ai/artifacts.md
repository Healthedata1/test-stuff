# Artifacts Summary - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

## Artifacts Summary

Contents:

*  [Structures: Resource Profiles](#1) 
*  [Terminology: Value Sets](#2) 
*  [Example: Example Instances](#3) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [US Core ADI DocumentReference Profile](StructureDefinition-us-core-adi-documentreference.md) | The US Core ADI DocumentReference Profile inherits from the FHIR[DocumentReference](https://hl7.org/fhir/R4/documentreference.html)resource; refer to it for scope and usage definitions. This profile and the[US Core Observation ADI Documentation Profile](StructureDefinition-us-core-observation-adi-documentation.md)meet the[U.S. Core Data for Interoperability (USCDI)](https://www.healthit.gov/isp/united-states-core-data-interoperability-uscdi)**Advance Directive Observation**Data Element requirements. It sets minimum expectations for searching and fetching patient Advance Directive Information (ADI) documents using the DocumentReference resource. Examples of advance healthcare directive documents include physician order for life sustaining treatment (POLST), do not resuscitate order (DNR), and medical power of attorney. In addition to the document contents, it communicates the type of advance directive document, the author, the verifier, and other properties. To represent whether advance directive documents exist for a patient, see the US Core Observation ADI Documentation Profile. This profile sets minimum expectations for searching and fetching patient ADI documents using the DocumentReference resource. It specifies which core elements, extensions, vocabularies, and value sets**SHALL**be present and constrains how the elements are used. Providing the floor for standards development for specific use cases promotes interoperability and adoption. |
| [US Core PMO ServiceRequest Profile](StructureDefinition-us-core-pmo-servicerequest.md) | The US Core PMO ServiceRequest Profile inherits from the[FHIR ServiceRequest](https://hl7.org/fhir/R4/servicerequest.html)resource; refer to it for scope and usage definitions. This profile represents an order based on a PMO document and references the[US Core ADI DocumentReference Profile](StructureDefinition-us-core-adi-documentreference.md)to communicate the contents of the PMO document, such as POLST, MOLST, or other state-specific forms. PMO documents follow the patient across care settings and are typically stored as scanned images in EMRs/EHRs. Together, these two profiles satisfy the USCDI's PMO Order Data Element's intent to represent orders based on an individual's PMO. The US Core PMO ServiceRequest Profile establishes minimum expectations for recording, searching, and fetching PMO-related ServiceRequest information, specifying core elements, extensions, vocabularies, and value sets that SHALL be present to promote interoperability. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [US Core Portable Medical Orders](ValueSet-us-core-portable-medical-orders.md) | A value set of LOINC codes for portable medical orders. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [CDEX Document with Digital Signature Example](Bundle-cdex-document-digital-sig-example.md) | Digital signature example showing how it is used to sign a FHIR Document. The CDEX use case would be the target resource in response to a Task-based request where a digital signature was required. If no signature was required, the response would typically be in the form of an individual resource. |
| [DocumentReference POLST (PDF)](DocumentReference-polst.md) | This is a an example of POLST (PDF) for the**US Core ADI DocumentReference Profile** |
| [Hospital Location](Location-hospital.md) | This is an example hospital location for the**US Core Location Profile**using three coding type, showing SNOMED CT, HSLOC, and v3-RoleCode concepts. |
| [ServiceRequest DNR Example](ServiceRequest-servicerequest-pmo-example1.md) | This is an example DNR request using the**US Core PMO ServiceRequest Profile**. |

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

