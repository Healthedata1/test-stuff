# Home - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

## Home

* [h3 element](#h3-element)
* [another h3 element](#another-h3-element) 
* [h4 element](#h4-element) 
* [h5 element](#h5-element) 
* [h6 element](#h6-element)
 
 
 
* [Cross Version Comparisons](#cross-version-comparisons)

☝️☝️☝️ {::options toc_levels="1..6"/} on first line

### h3 element

### another h3 element

#### h4 element

##### h5 element

###### h6 element

###### Another h6 element with the "no_toc" tag to omit from the toc

☝️☝️☝️ {:.no_toc} right after header

👇👇👇 included link list file

```
{% include r4-link-list.md %} <-- static list of a R4 resources
{% include page-link-list.md %} <--Uses liquid script to create a link list of all the ig pages from site.data.pages.json

```

hidden content looks like 👇👇👇

```
<!--this liquid script generate a link-list of the IG pages including  all the IG artifacts based on their titles Note that Commonmmark's shortcut reference links DO NOT support brackets '[]' in the link text -->[Table of Contents]: toc.html
[Home]: index.html
[Guidance]: guidance.html
[Downloads]: downloads.html
[ImplementationGuide Resource]: ImplementationGuide.html
[Change Log]: changes.html
[Artifacts Summary]: artifacts.html
[US Core ADI DocumentReference Profile]: StructureDefinition-us-core-adi-documentreference.html
[US Core ADI DocumentReference Profile - Definitions]: StructureDefinition-us-core-adi-documentreference-definitions.html
[US Core ADI DocumentReference Profile - Mappings]: StructureDefinition-us-core-adi-documentreference-mappings.html
[US Core ADI DocumentReference Profile - Testing]: StructureDefinition-us-core-adi-documentreference-testing.html
[US Core ADI DocumentReference Profile - Examples]: StructureDefinition-us-core-adi-documentreference-examples.html
[US Core ADI DocumentReference Profile - XML Representation]: StructureDefinition-us-core-adi-documentreference.profile.xml.html
[US Core ADI DocumentReference Profile - JSON Representation]: StructureDefinition-us-core-adi-documentreference.profile.json.html
[US Core ADI DocumentReference Profile - TTL Representation]: StructureDefinition-us-core-adi-documentreference.profile.ttl.html
[US Core PMO ServiceRequest Profile]: StructureDefinition-us-core-pmo-servicerequest.html
[US Core PMO ServiceRequest Profile - Definitions]: StructureDefinition-us-core-pmo-servicerequest-definitions.html
[US Core PMO ServiceRequest Profile - Mappings]: StructureDefinition-us-core-pmo-servicerequest-mappings.html
[US Core PMO ServiceRequest Profile - Testing]: StructureDefinition-us-core-pmo-servicerequest-testing.html
[US Core PMO ServiceRequest Profile - Examples]: StructureDefinition-us-core-pmo-servicerequest-examples.html
[US Core PMO ServiceRequest Profile - XML Representation]: StructureDefinition-us-core-pmo-servicerequest.profile.xml.html
[US Core PMO ServiceRequest Profile - JSON Representation]: StructureDefinition-us-core-pmo-servicerequest.profile.json.html
[US Core PMO ServiceRequest Profile - TTL Representation]: StructureDefinition-us-core-pmo-servicerequest.profile.ttl.html
[US Core Ethnicity Extension]: StructureDefinition-us-core-ethnicity.html
[US Core Ethnicity Extension - Definitions]: StructureDefinition-us-core-ethnicity-definitions.html
[US Core Ethnicity Extension - Mappings]: StructureDefinition-us-core-ethnicity-mappings.html
[US Core Ethnicity Extension - Testing]: StructureDefinition-us-core-ethnicity-testing.html
[US Core Ethnicity Extension - XML Representation]: StructureDefinition-us-core-ethnicity.profile.xml.html
[US Core Ethnicity Extension - JSON Representation]: StructureDefinition-us-core-ethnicity.profile.json.html
[US Core Ethnicity Extension - TTL Representation]: StructureDefinition-us-core-ethnicity.profile.ttl.html
[US Core Race Extension]: StructureDefinition-us-core-race.html
[US Core Race Extension - Definitions]: StructureDefinition-us-core-race-definitions.html
[US Core Race Extension - Mappings]: StructureDefinition-us-core-race-mappings.html
[US Core Race Extension - Testing]: StructureDefinition-us-core-race-testing.html
[US Core Race Extension - XML Representation]: StructureDefinition-us-core-race.profile.xml.html
[US Core Race Extension - JSON Representation]: StructureDefinition-us-core-race.profile.json.html
[US Core Race Extension - TTL Representation]: StructureDefinition-us-core-race.profile.ttl.html
[US Core Portable Medical Orders]: ValueSet-us-core-portable-medical-orders.html
[US Core Portable Medical Orders - Testing]: ValueSet-us-core-portable-medical-orders-testing.html
[US Core Portable Medical Orders - XML Representation]: ValueSet-us-core-portable-medical-orders.xml.html
[US Core Portable Medical Orders - JSON Representation]: ValueSet-us-core-portable-medical-orders.json.html
[US Core Portable Medical Orders - TTL Representation]: ValueSet-us-core-portable-medical-orders.ttl.html
[CDEX Document with Digital Signature Example]: Bundle-cdex-document-digital-sig-example.html
[CDEX Document with Digital Signature Example - XML Representation]: Bundle-cdex-document-digital-sig-example.xml.html
[CDEX Document with Digital Signature Example - JSON Representation]: Bundle-cdex-document-digital-sig-example.json.html
[CDEX Document with Digital Signature Example - TTL Representation]: Bundle-cdex-document-digital-sig-example.ttl.html
[DocumentReference POLST (PDF)]: DocumentReference-polst.html
[DocumentReference POLST (PDF) - XML Representation]: DocumentReference-polst.xml.html
[DocumentReference POLST (PDF) - JSON Representation]: DocumentReference-polst.json.html
[DocumentReference POLST (PDF) - TTL Representation]: DocumentReference-polst.ttl.html
[Hospital Location]: Location-hospital.html
[Hospital Location - XML Representation]: Location-hospital.xml.html
[Hospital Location - JSON Representation]: Location-hospital.json.html
[Hospital Location - TTL Representation]: Location-hospital.ttl.html
[Patient Example]: Patient-example.html
[Patient Example - XML Representation]: Patient-example.xml.html
[Patient Example - JSON Representation]: Patient-example.json.html
[Patient Example - TTL Representation]: Patient-example.ttl.html
[ServiceRequest DNR Example]: ServiceRequest-servicerequest-pmo-example1.html
[ServiceRequest DNR Example - XML Representation]: ServiceRequest-servicerequest-pmo-example1.xml.html
[ServiceRequest DNR Example - JSON Representation]: ServiceRequest-servicerequest-pmo-example1.json.html
[ServiceRequest DNR Example - TTL Representation]: ServiceRequest-servicerequest-pmo-example1.ttl.html
 


```

Try it:

* `[Table of Contents]` –> [Table of Contents](toc.md)
* `[Home]` –> [Home](index.md)
* `[Guidance]` –> [Guidance](guidance.md)
* `[Downloads]` –> [Downloads](downloads.md)
* `[ImplementationGuide Resource]` –> [ImplementationGuide Resource](ImplementationGuide.md)
* `[Change Log]` –> [Change Log](changes.md)
* `[Artifacts Summary]` –> [Artifacts Summary](artifacts.md)
* `[Observation]` –> [Observation](http://hl7.org/fhir/R4/observation.html)
* `[component]` –> [component](foo.md)

### Cross Version Comparisons

The table below summarizes the different profiles and resource types between Argonaut Data Query and major releases of US Core :

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

