# US Core Race Extension - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Race Extension**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-us-core-race-definitions.md) 
*  [JSON](StructureDefinition-us-core-race.profile.json.md) 

## Extension: US Core Race Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/core/StructureDefinition/us-core-race | *Version*:0.1.0 |
| Active as of 2023-10-17 | *Computable Name*:USCoreRaceExtension |

Concepts classifying the person into a named category of humans sharing common history, traits, geographical origin or nationality. The race codes used to represent these concepts are based upon the [Race & Ethnicity - CDC (CDCREC)](https://phinvads.cdc.gov/vads/ViewCodeSystem.action?id=2.16.840.1.113883.6.238) which includes over 900 concepts for representing race and ethnicity of which 921 reference race. The race concepts are grouped by and pre-mapped to the 5 OMB race categories:

* American Indian or Alaska Native
* Asian
* Black or African American
* Native Hawaiian or Other Pacific Islander
* White.

Complies with 2015 Edition Common Clinical Data Set for patient race.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [US Core Patient Profile](http://hl7.org/fhir/us/core/STU8/StructureDefinition-us-core-patient.html)
* Examples for this Extension: [Patient/example](Patient-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.us.healthedata1-sandbox|current/StructureDefinition/us-core-race)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: Concepts classifying the person into a named category of humans sharing common history, traits, geographical origin or nationality. The race codes used to represent these concepts are based upon the [Race & Ethnicity - CDC (CDCREC)](https://phinvads.cdc.gov/vads/ViewCodeSystem.action?id=2.16.840.1.113883.6.238) which includes over 900 concepts for representing race and ethnicity of which 921 reference race. The race concepts are grouped by and pre-mapped to the 5 OMB race categories: 
* American Indian or Alaska Native
* Asian
* Black or African American
* Native Hawaiian or Other Pacific Islander
* White.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: Concepts classifying the person into a named category of humans sharing common history, traits, geographical origin or nationality. The race codes used to represent these concepts are based upon the [Race & Ethnicity - CDC (CDCREC)](https://phinvads.cdc.gov/vads/ViewCodeSystem.action?id=2.16.840.1.113883.6.238) which includes over 900 concepts for representing race and ethnicity of which 921 reference race. The race concepts are grouped by and pre-mapped to the 5 OMB race categories: 
* American Indian or Alaska Native
* Asian
* Black or African American
* Native Hawaiian or Other Pacific Islander
* White.

 

Other representations of profile: [CSV](StructureDefinition-us-core-race.csv), [Excel](StructureDefinition-us-core-race.xlsx), [Schematron](StructureDefinition-us-core-race.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

