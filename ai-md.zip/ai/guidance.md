# Guidance - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Guidance**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

## Guidance

* [Guidance](#guidance)
* [another h3 element](#another-h3-element)
* [Client Best Practices for Search:](#client-best-practices-for-search)

### Guidance

### another h3 element

#### h4 element

##### h5 element

###### h6 element

###### Another h6 element with the "no_toc" tag to omit from the toc

☝️☝️☝️ {:.no_toc} right after header

### Client Best Practices for Search:

**Figure 1: Test SVG No Comment**
![](test-no-comment.svg)

```
<svg height="100" width="100" xmlns="http://www.w3.org/2000/svg">
  <circle r="45" cx="50" cy="50" stroke="green" stroke-width="3" fill="red" opacity="0.5" /></svg> 

```

**Figure 1: Test SVG with Comment**
![](test-comment.svg)

```
<!-- 
comment 
 this is a comment with a  <nested html tag>
 -->
<svg height="100" width="100" xmlns="http://www.w3.org/2000/svg">
  <circle r="45" cx="50" cy="50" stroke="green" stroke-width="3" fill="red" opacity="0.5" /></svg> 

```

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

