# ImplementationGuide Resource - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **ImplementationGuide Resource**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

## ImplementationGuide Resource

* [Cross Version Analysis](#cross-version-analysis)
* [IG Dependencies](#ig-dependencies)
* [Global Profiles](#global-profiles)
* [Copyrights](#copyrights)
* [Parameter Settings](#parameter-settings)

| | |
| :--- | :--- |
| **Official URL**: | **Version**: |
| **NPM package name**: | **ComputableName**: |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License |   |

* [XML](ImplementationGuide-.xml)
* [JSON](ImplementationGuide-.json)

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B} systems. Packages for both [R4 (hl7.fhir.us.healthedata1-sandbox.r4)](package.r4.tgz) and [R4B (hl7.fhir.us.healthedata1-sandbox.r4b)](package.r4b.tgz) are available. 

### IG Dependencies

This IG Contains the following dependencies on other IGs.





### Global Profiles

*There are no Global profiles defined*

### Copyrights

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [HealthEData_1Sandbox](index.md), [USCoreADIDocumentReferenceProfile](StructureDefinition-us-core-adi-documentreference.md)...Show 4 more,[USCoreEthnicityExtension](StructureDefinition-us-core-ethnicity.md),[USCorePMOServiceRequestProfile](StructureDefinition-us-core-pmo-servicerequest.md),[USCorePortableMedicalOrders](ValueSet-us-core-portable-medical-orders.md)and[USCoreRaceExtension](StructureDefinition-us-core-race.md)


* Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission.For information and exceptions regarding use of CDC material please see [https://www.cdc.gov/other/agencymaterials.html](https://www.cdc.gov/other/agencymaterials.html).

* [CDC Race and Ethnicity](http://terminology.hl7.org/6.5.0/CodeSystem-CDCREC.html): [Patient/example](Patient-example.md), [USCoreEthnicityExtension](StructureDefinition-us-core-ethnicity.md) and [USCoreRaceExtension](StructureDefinition-us-core-race.md)


* These codes are excerpted from ASTM Standard, E1762-95(2013) - Standard Guide for Electronic Authentication of Health Care Information, Copyright by ASTM International, 100 Barr Harbor Drive, West Conshohocken, PA 19428. Copies of this standard are available through the ASTM Web Site at www.astm.org.

* [Signature Type Codes](http://hl7.org/fhir/R4/codesystem-signature-type.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md), [DocumentReference/polst](DocumentReference-polst.md)...Show 4 more,[ServiceRequest/servicerequest-pmo-example1](ServiceRequest-servicerequest-pmo-example1.md),[USCoreADIDocumentReferenceProfile](StructureDefinition-us-core-adi-documentreference.md),[USCorePMOServiceRequestProfile](StructureDefinition-us-core-pmo-servicerequest.md)and[USCorePortableMedicalOrders](ValueSet-us-core-portable-medical-orders.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md), [Holy Family Hospital](Location-hospital.md), [Patient/example](Patient-example.md), [ServiceRequest/servicerequest-pmo-example1](ServiceRequest-servicerequest-pmo-example1.md) and [USCorePMOServiceRequestProfile](StructureDefinition-us-core-pmo-servicerequest.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/6.5.0/CodeSystem-condition-category.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/6.5.0/CodeSystem-condition-clinical.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md)
* [DataAbsentReason](http://terminology.hl7.org/6.5.0/CodeSystem-data-absent-reason.html): [USCoreEthnicityExtension](StructureDefinition-us-core-ethnicity.md) and [USCoreRaceExtension](StructureDefinition-us-core-race.md)
* [identifierType](http://terminology.hl7.org/6.5.0/CodeSystem-v2-0203.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md) and [Patient/example](Patient-example.md)
* [ActCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html): [Bundle/cdex-document-digital-sig-example](Bundle-cdex-document-digital-sig-example.md)
* [HL7 Document Format Codes](http://terminology.hl7.org/6.5.0/CodeSystem-v3-HL7DocumentFormatCodes.html): [USCoreADIDocumentReferenceProfile](StructureDefinition-us-core-adi-documentreference.md)
* [NullFlavor](http://terminology.hl7.org/6.5.0/CodeSystem-v3-NullFlavor.html): [USCoreEthnicityExtension](StructureDefinition-us-core-ethnicity.md) and [USCoreRaceExtension](StructureDefinition-us-core-race.md)
* [RoleCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-RoleCode.html): [Holy Family Hospital](Location-hospital.md)
* [TribalEntityUS](http://terminology.hl7.org/6.5.0/CodeSystem-v3-TribalEntityUS.html): [Patient/example](Patient-example.md)


### Parameter Settings

The following [IG Parameters](https://confluence.hl7.org/display/FHIR/Implementation+Guide+Parameters) are set for this Implementation Guide:

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

