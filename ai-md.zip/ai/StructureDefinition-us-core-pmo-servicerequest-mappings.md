# US Core PMO ServiceRequest Profile - Mappings - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core PMO ServiceRequest Profile**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](StructureDefinition-us-core-pmo-servicerequest.md) 
*  [Detailed Descriptions](StructureDefinition-us-core-pmo-servicerequest-definitions.md) 
*  [Examples](StructureDefinition-us-core-pmo-servicerequest-examples.md) 
*  [JSON](StructureDefinition-us-core-pmo-servicerequest.profile.json.md) 

## Resource Profile: USCorePMOServiceRequestProfile - Mappings

| |
| :--- |
| Draft as of 2025-08-26 |

Mappings for the us-core-pmo-servicerequest resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

