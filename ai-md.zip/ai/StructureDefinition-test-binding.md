# Test Binding - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Test Binding**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-test-binding-definitions.md) 
*  [Examples](StructureDefinition-test-binding-examples.md) 
*  [JSON](StructureDefinition-test-binding.profile.json.md) 

## Resource Profile: Test Binding 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/StructureDefinition/test-binding | *Version*:0.1.0 |
| Draft as of 2025-08-22 | *Computable Name*:TestBinding |

 
A profile on the FHIR R4 Basic resource for representing a referral, with the code element constrained to the LOINC valid HL7 attachment requests value set. 

**Usages:**

* Examples for this Profile: [Basic/example-referral](Basic-example-referral.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.us.healthedata1-sandbox|current/StructureDefinition/test-binding)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Basic](http://hl7.org/fhir/R4/basic.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Basic](http://hl7.org/fhir/R4/basic.html) 

**Summary**

Mandatory: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Basic](http://hl7.org/fhir/R4/basic.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Basic](http://hl7.org/fhir/R4/basic.html) 

**Summary**

Mandatory: 1 element

 

Other representations of profile: [CSV](StructureDefinition-test-binding.csv), [Excel](StructureDefinition-test-binding.xlsx), [Schematron](StructureDefinition-test-binding.sch) 

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

