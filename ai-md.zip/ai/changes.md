# Change Log - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Change Log**

Health eData 1 Sandbox - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)

## Change Log

* [Version = Continuous Integration (CI) Build](#version--continuous-integration-ci-build)
* [Version = 4.1.0](#version--410)

### Version = Continuous Integration (CI) Build

* url: [http://build.fhir.org/ig/HL7/US-Core](http://build.fhir.org/ig/HL7/US-Core)
* Based on FHIR version : 4.0.1

#### Changes:

Continuous Integration Build (latest in version control) - **Content subject to frequent changes**

-------

### Version = 4.1.0

* Publication Date: 2021-11-30
* url: [http://hl7.org/fhir/us/core/2022Jan](http://hl7.org/fhir/us/core/2022Jan)
* Based on FHIR version : 4.0.1

#### Changes:

**The January 2022 Ballot**

This Ballot addresses the following issues:

1. foo
1. bar

 IG © 2020+ [HL7 International / Payer/Provider Information Exchange Work Group](http://www.hl7.org/Special/committees/claims). Package hl7.fhir.us.healthedata1-sandbox#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://hl7.org/fhir/us/healthedata1-sandbox/history.html)|![](cc0.png)|[Propose a change](http://hl7.org/fhir-issues) 

